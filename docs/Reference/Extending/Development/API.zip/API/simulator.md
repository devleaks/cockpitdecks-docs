# Simulator

[[Extending/Development/API/index|Entities]]


::: cockpitdecks.simulator
