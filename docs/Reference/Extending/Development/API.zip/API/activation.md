# Activation

[[Extending/Development/API/index|Entities]]


::: cockpitdecks.buttons.activation.activation
