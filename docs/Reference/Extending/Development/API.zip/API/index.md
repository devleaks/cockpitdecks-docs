# Cockpitdecks API

Here are the main Cockpitdecks entities meant to be extended by developers

- [[Extending/Development/API/representation|Representation]]
- [[Extending/Development/API/deck|Deck]]
- [[Extending/Development/API/resources/decktype.md|Deck Type]]
- [[Extending/Development/API/instruction|Instruction]]
- [[Extending/Development/API/activation|Activation]]
- [[Extending/Development/API/simulator|Simulator]]

