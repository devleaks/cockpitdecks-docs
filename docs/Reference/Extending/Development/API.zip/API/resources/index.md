# Cockpitdecks API - Resources

[[Extending/Development/API/index|Entities]]


- [[Extending/Development/API/resources/decktype|Deck Types]]
