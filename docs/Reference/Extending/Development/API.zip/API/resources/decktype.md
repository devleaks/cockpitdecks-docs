# Deck Type

[[Extending/Development/API/index|Entities]] > [[Extending/Development/API/resources/index|Resources]]


::: cockpitdecks.decks.resources.decktype
