# Cockpitdecks API

Here are the main Cockpitdecks entities meant to be extended by developers

- [[Reference/Extending/Development/API/representation|Representation]]
- [[Reference/Extending/Development/API/deck|Deck]]
- [[Reference/Extending/Development/API/resources/decktype.md|Deck Type]]
- [[Reference/Extending/Development/API/instruction|Instruction]]
- [[Reference/Extending/Development/API/activation|Activation]]
- [[Reference/Extending/Development/API/simulator|Simulator]]

