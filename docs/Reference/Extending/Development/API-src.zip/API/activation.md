# Activation

[[Reference/Extending/Development/API/index|Entities]]


::: cockpitdecks.buttons.activation.activation
