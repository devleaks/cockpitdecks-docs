# Simulator

[[Reference/Extending/Development/API/index|Entities]]


::: cockpitdecks.simulator
