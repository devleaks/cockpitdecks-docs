# Deck

[[Reference/Extending/Development/API/index|Entities]]


::: cockpitdecks.deck
    options:
      show_inheritance_diagram: true
