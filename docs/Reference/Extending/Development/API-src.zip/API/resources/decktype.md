# Deck Type

[[Reference/Extending/Development/API/index|Entities]] > [[Reference/Extending/Development/API/resources/index|Resources]]


::: cockpitdecks.decks.resources.decktype
