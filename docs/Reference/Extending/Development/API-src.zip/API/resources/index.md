# Cockpitdecks API - Resources

[[Reference/Extending/Development/API/index|Entities]]


- [[Reference/Extending/Development/API/resources/decktype|Deck Types]]
